scoreboard objectives add upgradedmobs.evokers.raid dummy
