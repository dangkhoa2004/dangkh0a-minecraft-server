tag @s add upgradedmobs.witches.potion.checked

execute if entity @e[distance=..2.5, type=witch, tag=!upgradedmobs.blacklist] run function upgradedmobs:witches/potion/splash
#execute on owner unless entity @s[type=witch, tag=!upgradedmobs.blacklist] run return fail
#function upgradedmobs:witches/potion/splash
