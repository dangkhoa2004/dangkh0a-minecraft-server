tag @s add upgradedmobs.witches.potion

execute if entity @p[distance=..9] if predicate math:chance/10 run data merge entity @s {Item:{components: {"potion_contents": {custom_effects:[{id:"minecraft:blindness",duration:120}]}}}}

data modify storage upgradedmobs:witch/potion/storage components set from entity @s Item.components
data modify storage upgradedmobs:witch/potion/storage Owner set from entity @s Owner
data modify storage upgradedmobs:witch/potion/storage Motion set from entity @s Motion
data modify storage upgradedmobs:witch/potion/storage Rotation set from entity @s Rotation

execute if predicate math:chance/25 if entity @p[distance=4..9] run summon lingering_potion ~ ~ ~
execute as @e[type=lingering_potion, limit=1, sort=nearest] run function upgradedmobs:witches/potion/lingering
execute if entity @e[type=lingering_potion, distance=..1, tag=upgradedmobs.witches.potion] run kill @s
