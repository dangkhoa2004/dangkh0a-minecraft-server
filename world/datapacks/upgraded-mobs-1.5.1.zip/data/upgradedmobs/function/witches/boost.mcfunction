attribute @s max_health modifier add upgradedmobs:witches/boost 2.3 add_multiplied_base
effect give @s instant_health 1 200 true

tag @s add upgradedmobs.boosted
