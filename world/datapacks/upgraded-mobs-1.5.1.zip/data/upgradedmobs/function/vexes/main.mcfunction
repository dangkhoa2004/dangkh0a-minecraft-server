execute if data entity @s bound_pos unless entity @e[type=evoker, tag=!upgradedmobs.blacklist, distance=..30] run kill @s
