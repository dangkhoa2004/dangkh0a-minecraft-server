attribute @s knockback_resistance base set 0.75

execute if predicate math:chance/10 run item replace entity @s armor.head with netherite_helmet[enchantments={"minecraft:fire_protection": 3, "minecraft:vanishing_curse": 1}, trim={pattern: snout, material: gold}]
execute if predicate math:chance/10 run item replace entity @s armor.chest with netherite_chestplate[enchantments={"minecraft:thorns": 2, "minecraft:vanishing_curse": 1}, trim={pattern: snout, material: gold}]
execute if predicate math:chance/10 run item replace entity @s armor.legs with netherite_leggings[enchantments={"minecraft:projectile_protection": 3, "minecraft:vanishing_curse": 1}, trim={pattern: snout, material: gold}]
execute if predicate math:chance/10 run item replace entity @s armor.feet with netherite_boots[enchantments={"minecraft:soul_speed": 2, "minecraft:vanishing_curse": 1}, trim={pattern: snout, material: gold}]

execute if predicate math:chance/25 run item replace entity @s weapon.mainhand with golden_axe[enchantments={"minecraft:knockback": 1}]
execute if predicate math:chance/10 run item replace entity @s weapon.mainhand with golden_axe[enchantments={"minecraft:knockback": 2}]

tag @s add upgradedmobs.boosted
