execute at @e[type=marker, tag=upgradedmobs.spider.web] run fill ~ ~ ~ ~ ~ ~ air replace cobweb
execute as @e[type=marker, tag=upgradedmobs.spider.web] run kill @s
