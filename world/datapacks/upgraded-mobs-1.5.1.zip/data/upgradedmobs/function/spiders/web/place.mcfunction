setblock ~ ~ ~ cobweb keep
summon marker ~ ~ ~ {Tags:[upgradedmobs.spider.web]}
schedule function upgradedmobs:spiders/web/clear 3s replace

particle item_snowball ^ ^1.5 ^0.5 0.1 0.1 0.1 0.001 3 normal

#playsound minecraft:block.honey_block.slide block @a ~ ~ ~ 2 1
playsound minecraft:entity.slime.attack hostile @a ~ ~ ~ 1 2
