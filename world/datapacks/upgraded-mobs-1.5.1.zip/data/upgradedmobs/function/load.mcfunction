scoreboard objectives add upgradedmobs.clock dummy
scoreboard objectives add upgradedmobs.health dummy

function upgradedmobs:config

tellraw @a "Upgraded Mobs loaded!"
