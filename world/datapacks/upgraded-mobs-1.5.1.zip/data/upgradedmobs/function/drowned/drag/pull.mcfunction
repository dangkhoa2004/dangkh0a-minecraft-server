particle bubble_column_up ~ ~ ~

execute unless entity @s[tag=upgradedmobs.drowned_sound] run playsound block.bubble_column.whirlpool_inside hostile @a ~ ~ ~ 0.75
tag @s add upgradedmobs.drowned_sound

effect give @s slowness 1 2 true
tp @s ~ ~-0.15 ~

function upgradedmobs:drowned/drag/boat
