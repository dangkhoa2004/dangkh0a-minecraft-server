function too_expensive_removed:image/set_image_data {\
  width: 8,\
  height: 8,\
  image_data: [\
    "#bba67a", "#4c3d29", "#473824", "#64ba50", "#5db14a", "#453827", "#4c3d29", "#bba67a",\
    "#b39b65", "#ae935c", "#bba67a", "#5db14a", "#64ba50", "#bba67a", "#b39b65", "#b39b65",\
    "#4c3d29", "#ae935c", "#b39b65", "#bba67a", "#bba67a", "#bba67a", "#b39b65", "#4c3d29",\
    "#4c3d29", "#4f402b", "#453827", "#453827", "#4c3d29", "#4f402b", "#4c3d29", "#4c3d29",\
    "#4f402b", "#453827", "#4f402b", "#cc9e72", "#cea37a", "#4c3d29", "#4f402b", "#453827",\
    "#cea37a", "#1f1200", "#cea37a", "#cea37a", "#cea37a", "#cea37a", "#1f1200", "#cea37a",\
    "#cc9e72", "#cea37a", "#cea37a", "#cca077", "#cca077", "#cea37a", "#cea37a", "#cea37a",\
    "#c69363", "#cc9e72", "#cea37a", "#1f1200", "#1f1200", "#cea37a", "#cc9e72", "#c69363"\
  ],\
  background_color: "#303030",\
  description: [\
    {text: "Too Expensive Removed"},\
    {translate: "too_expensive_removed.description", fallback: "Removes the 'Too Expensive!' limitation from anvils"},\
    "",\
    [{translate: "jodek.datapack_version", fallback: "Datapack version: ", color: "#00a800"}, {text: "v1.2.6", color: "#54fc54"}],\
    "",\
    [{translate: "jodek.by", fallback: "By ", color: "#fcfcfc"}, {text: "Jodek", color: "#fcfc54"}],\
    {text: "modrinth.com/datapack/too-expensive-removed", color: "#a800a8"},\
    "",\
    "",\
    "",\
    "",\
    "",\
    ""\
  ]\
}