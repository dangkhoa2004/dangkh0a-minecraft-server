setblock ~ ~ ~ air
kill @s
