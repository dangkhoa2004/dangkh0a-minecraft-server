execute in minecraft:the_end run setblock ~ ~-2 ~ structure_block[mode=load]{name:"far_end:exit_portal/deactivated",posX:-6,posY:0,posZ:-6,rotation:"NONE",mirror:"NONE",mode:"LOAD"} replace
execute in minecraft:the_end run setblock ~ ~-1 ~ minecraft:redstone_block
