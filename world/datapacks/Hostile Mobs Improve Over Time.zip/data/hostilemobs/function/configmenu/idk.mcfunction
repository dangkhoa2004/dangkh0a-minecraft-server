say yooo
$say $(bogged)