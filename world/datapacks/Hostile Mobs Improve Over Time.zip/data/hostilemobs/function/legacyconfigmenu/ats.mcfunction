scoreboard players set #playersconfig HostileMobs 0
function hostilemobs:legacyconfigmenu/difficulty
# made by KNIZE_1007
# Officialy published only on Modrinth and planet minecraft
# Other websites have reuploaded without my consent and are in breach of the licence
